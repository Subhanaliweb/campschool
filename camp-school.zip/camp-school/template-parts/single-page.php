<?php /* This is a single page */ ?>

<?php 
    if(have_posts()):
        while(have_posts()): the_post();
        ?>
        <?php $thumbnail=get_the_post_thumbnail_url(get_the_id(),'full'); ?>
        <?php if (!empty($thumbnail)){ ?>
        	<div class="parallax-mirror" style="visibility: visible; z-index: -100; position: absolute; top: 0px; left: 0px; overflow: hidden; height: 300px; min-width: 100%;"><img class="parallax-slider" src="<?php echo $thumbnail; ?>" style="transform: translate3d(0px, -206.2px, 0px); position: absolute; height: 562px; min-width: 100%; max-width: none;"></div>

		    <div class="cm-hero d-flex justify-content-center align-items-center image-overlay" data-parallax="scroll" data-image-src="<?php echo $thumbnail ; ?>">
		        	<h1><?php the_title() ?></h1>
		    </div>
        <?php }
         else { ?>

    		<div class="parallax-mirror" style="visibility: visible; z-index: -100; position: absolute; top: 0px; left: 0px; overflow: hidden; height: 300px; min-width: 100%;"><img class="parallax-slider" src="http://localhost/first/wp-content/uploads/2021/03/high-school-1.jpg" style="transform: translate3d(0px, -206.2px, 0px); position: absolute; height: 562px; min-width: 100%; max-width: none;"></div>

		    <div class="cm-hero d-flex justify-content-center align-items-center image-overlay" data-parallax="scroll" data-image-src="http://localhost/first/wp-content/uploads/2021/03/high-school-1.jpg">
		        	<h1><?php the_title() ?></h1>
		    </div>
    		<?php } ?>
     </div>
      <div class="container-fluid cm-container-content cm-mt-60">
        <div class="row mb-4">
            <h2 class="col-12 cm-text-primary"><?php the_title(); ?></h2>
        </div>
        <div class="row cm-mb-90">            
            <div class="col-xl-8 col-lg-7 col-md-6 col-sm-12">
                <img src="<?php echo $thumbnail;?>" alt="<?php the_title() ?>" class="img-fluid">
            </div>
            <?php the_tags() ?>
            <div class="col-xl-4 col-lg-5 col-md-6 col-sm-12">
                	<?php get_sidebar(); ?>
            </div>
            </div>
            <div class="row mb-4">
            <h2 class="col-12 cm-text-primary">
                Related Photos
            </h2>
        </div>
        <div class="row mb-3 cm-gallery">
        	<?php 
			$related = get_posts( array( 'category__in' => wp_get_post_categories($post->ID), 'numberposts' => 4, 'post__not_in' => array($post->ID) ) );
			if( $related ) foreach( $related as $postdata ) {
			setup_postdata($postdata); ?>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                <figure class="effect-ming cm-video-item">
                    <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="Image" class="img-fluid">
                    <figcaption class="d-flex align-items-center justify-content-center">
                        <h2><?php the_title(); ?></h2>
                        <a href="<?php the_permalink() ?>">View more</a>
                    </figcaption>                    
                </figure>
                <div class="d-flex justify-content-between cm-text-gray">
                    <span class="cm-text-gray-light"><?php echo get_the_date( 'M j Y' ); ?></span>
                    <span><?php echo (int) get_post_meta(get_the_ID(), 'post_views_count', true) . ' Views'; ?></span>
                </div>
            </div> 
            <?php }
						wp_reset_postdata(); ?>
        </div> <!-- row -->
    </div> <!-- container-fluid, cm-container-content -->
    <?php
     wp_list_comments();
     paginate_comments_links();
     
        endwhile;
        endif;
         ?>