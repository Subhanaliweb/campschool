<?php /* This category template */ ?>

<?php global $query_string;
parse_str( $query_string, $args );
$args['post_type'] = 'post';
$args['posts_per_page'] = 12;
query_posts($args);
$all_posts = new Wp_Query($args);

 if ($all_posts->have_posts()): ?>
        <?php $thumbnail=wp_get_attachment_url( get_post_thumbnail_id(get_option( 'page_for_posts','full' )) ); ?>
        <?php if (!empty($thumbnail)){ ?>
            <div class="parallax-mirror" style="visibility: visible; z-index: -100; position: absolute; top: 0px; left: 0px; overflow: hidden; height: 300px; min-width: 100%;"><img class="parallax-slider" src="<?php echo $thumbnail; ?>" style="transform: translate3d(0px, -206.2px, 0px); position: absolute; height: 562px; min-width: 100%; max-width: none;"></div>

            <div class="cm-hero d-flex justify-content-center align-items-center image-overlay" data-parallax="scroll" data-image-src="<?php echo $thumbnail ; ?>">
                    <h1><?php echo $our_title = single_cat_title(); ?></h1>
            </div>
        <?php }
         else { ?>

            <div class="parallax-mirror" style="visibility: visible; z-index: -100; position: absolute; top: 0px; left: 0px; overflow: hidden; height: 300px; min-width: 100%;"><img class="parallax-slider" src="http://localhost/first/wp-content/uploads/2021/03/high-school-1.jpg" style="transform: translate3d(0px, -206.2px, 0px); position: absolute; height: 562px; min-width: 100%; max-width: none;"></div>

            <div class="cm-hero d-flex justify-content-center align-items-center image-overlay" data-parallax="scroll" data-image-src="http://localhost/first/wp-content/uploads/2021/03/high-school-1.jpg">
                    <h1><?php echo $our_title = get_the_title( get_option('page_for_posts', true) ); ?></h1>
            </div>
            <?php } ?>

            <div class="container-fluid cm-container-content cm-mt-60">
        <div class="row mb-4">
            <h2 class="col-6 cm-text-primary">
                <?php echo $our_title = single_cat_title(); ?>
            </h2>
            <div class="col-6 d-flex justify-content-end align-items-center">
                <form action="" class="cm-text-primary">
                    <?php $numbed = (get_query_var('paged')) ? get_query_var('paged') : 1;
                        global $wp_query;
                     ?>
                    Page <input type="text" value="<?php echo $numbed; ?>" size="1" class="cm-input-paging cm-text-primary" readonly> of <?php echo $wp_query->max_num_pages; ?>
                </form>
            </div>
        </div>
<div class="row cm-mb-90 cm-gallery">
        <?php 
// $args= array(
// 'cat' => 5
// );
  while($all_posts->have_posts()) : $all_posts->the_post();
 ?>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                <figure class="effect-ming cm-video-item">
                    <?php if( !empty(get_the_post_thumbnail()) ) { ?>
                    <img height="176px" src=" <?php the_post_thumbnail_url(); ?>" alt="Image" class="img-fluid">
                <?php } ?>
                    <figcaption class="d-flex align-items-center justify-content-center">
                        <h2><?php the_title(); ?></h2>
                        <a href="<?php the_permalink() ?>">View more</a>
                    </figcaption>                    
                </figure>
                <div class="d-flex justify-content-between cm-text-gray">
                    <span class="cm-text-gray-light"><?php echo get_the_date( 'M j Y' ); ?></span>
                    <span><?php echo get_post_meta(get_the_ID(), 'post_views_count', true) . ' Views'; ?>
                    </span>
                </div>
            </div>
        
    <?php   endwhile;
            endif;
     ?>
     </div>         
         <!-- row -->
     <div class="row mb-5">
            <div class="col-12 d-flex justify-content-between align-items-center cm-paging-col">
                <?php if(get_previous_posts_link()){
                    echo '<span class="main-button mb-2 ">'.get_previous_posts_link(esc_html__('Previous','camp-school')).'</span>';
                } else
                {
                   echo ' <a href="javascript:void(0);" class="btn-primary mb-2 disabled">Previous</a>';
                }?>
                <div class="cm-paging d-flex">

                    <?php the_posts_pagination( array(
                'mid_size'=>3,
                'prev_text' => "_( '')",
                'next_text' => "_( '')",
            ) ); ?>
                </div>
                <?php if(get_next_posts_link()){
                    echo '<span class="main-button mb-2">'.get_next_posts_link(esc_html__('Next','camp-school')).'</span>';
                } 
                else {
                echo ' <a href="javascript:void(0);" class="btn-primary mb-2 disabled">Next</a>';
                }
                    ?>
            </div>            
        </div>
    </div> 