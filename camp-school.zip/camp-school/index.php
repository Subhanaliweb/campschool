<?php
/*
This is a blog page
*/

	 get_header();
	 	if(have_posts()): 
	 		get_template_part('template-parts/blog','page');
		endif; 
	 get_footer();