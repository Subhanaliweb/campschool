<?php
/*
This is a category page
*/

 	get_header();
	 	if(have_posts()): 
	 		get_template_part('template-parts/catog','page');
		endif; 
	get_footer();
