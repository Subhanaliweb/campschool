<?php 

function camp_school_import_files() {
  return [
    [
      'import_file_name'             => 'Camp School Demo Data Import',
      'categories'                   => [ 'Category' ],
      // 'import_file_url'            => 'https://firebasestorage.googleapis.com/v0/b/campschool202.appspot.com/o/content.xml?alt=media&token=e256e25c-a556-493e-a888-aa49a0534b40',
      // 'import_widget_file_url'     => 'https://firebasestorage.googleapis.com/v0/b/campschool202.appspot.com/o/widgets.wie?alt=media&token=77590aa2-c545-458f-bf67-3e30f1897319',
      'local_import_file'            => trailingslashit( get_template_directory() ) . 'demo-data/content.xml',
      'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'demo-data/widgets.wie',
      'local_import_preview_image_url'     => trailingslashit( get_template_directory() ) . 'demo-data/screenshot.png',
    ],
  ];
}
add_filter( 'ocdi/import_files', 'camp_school_import_files' );
function camp_school_after_import_setup() {
  // Assign menus to their locations.
  $main_menu = get_term_by( 'name', 'Primary', 'nav_menu' );

  set_theme_mod( 'nav_menu_locations', array(
      'Primary' => $main_menu->term_id, // replace 'main-menu' here with the menu location identifier from register_nav_menu() function
    )
  );

  // Assign front page and posts page (blog page).
  $front_page_id = get_page_by_title( 'Home' );
  $blog_page_id  = get_page_by_title( 'Blog' );

  update_option( 'show_on_front', 'page' );
  update_option( 'page_on_front', $front_page_id->ID );
  update_option( 'page_for_posts', $blog_page_id->ID );

}
add_action( 'ocdi/after_import', 'camp_school_after_import_setup' );

function camp_school_register_plugins( $plugins ) {
  $theme_plugins = [
    [ // A WordPress.org plugin repository example.
      'name'     => 'Kirki Customizer Framework', // Name of the plugin.
      'slug'     => 'kirki', // Plugin slug - the same as on WordPress.org plugin repository.
      'required' => false,                     // If the plugin is required or not.
    ],
    [ // A WordPress.org plugin repository example.
      'name'     => 'Contact Form 7', // Name of the plugin.
      'slug'     => 'contact-form-7', // Plugin slug - the same as on WordPress.org plugin repository.
      'required' => false,                     // If the plugin is required or not.
    ],
  ];
 
  return array_merge( $plugins, $theme_plugins );
}
add_filter( 'ocdi/register_plugins', 'camp_school_register_plugins' );