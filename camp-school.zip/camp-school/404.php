<!DOCTYPE html>
<html lang="en">
<?php wp_head(); ?>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>

  <div id="notfound">
    <div class="notfound">
      <div class="notfound-404">
        <h1 style="line-height: 153px ;">4<span>0</span>4</h1>
      </div>
      <p>The page you are looking for might have been removed had its name changed or is temporarily unavailable.</p>
      <a href="<?php echo esc_url(get_home_url()); ?>">home page</a>
    </div>
  </div>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
