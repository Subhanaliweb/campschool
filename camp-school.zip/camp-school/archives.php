<?php
/*
This is an archive page
*/

	 get_header();
	 	if(have_posts()): 
	 		get_template_part('template-parts/archive','page');
		endif; 
	 get_footer();