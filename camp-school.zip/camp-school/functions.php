<?php 
function camp_school_enqueue_scripts(){
wp_enqueue_style('flex-slider',get_template_directory_uri().'/assets/css/flex-slider.css');
wp_enqueue_style('fontawesome',get_template_directory_uri().'/assets/css/fontawesome.css');
wp_enqueue_style('lightbox',get_template_directory_uri().'/assets/css/lightbox.css');
wp_enqueue_style('owl',get_template_directory_uri().'/assets/css/owl.css');
wp_enqueue_style('bootstrapcss',get_template_directory_uri().'/assets/bootstrap/css/bootstrap.min.css');
wp_enqueue_style('404-css',get_template_directory_uri().'/assets/css/404.css');
wp_enqueue_style('google-fonts','https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900');
wp_enqueue_style('google-fontjosefin','https://fonts.googleapis.com/css?family=Josefin+Sans:400,700');
wp_enqueue_style('style',get_stylesheet_uri());
wp_enqueue_script('jquery');
}
 function camp_school_scripts_footer(){
  	wp_enqueue_script('bootstrapjs',get_template_directory_uri().'/assets/bootstrap/js/bootstrap.min.js',array(),false,true);
	wp_enqueue_script('isotope',get_template_directory_uri().'/assets/js/isotope.min.js',array(),false,true);
	wp_enqueue_script('owl-carousel',get_template_directory_uri().'/assets/js/owl-carousel.js',array(),false,true);
	wp_enqueue_script('lightbox',get_template_directory_uri().'/assets/js/lightbox.js',array(),false,true,array(),false,true);
	wp_enqueue_script('tabs',get_template_directory_uri().'/assets/js/tabs.js',array(),false,true);
	wp_enqueue_script('video',get_template_directory_uri().'/assets/js/video.js',array(),false,true);
	wp_enqueue_script('slick-slider',get_template_directory_uri().'/assets/js/slick-slider.js',array(),false,true);
	wp_enqueue_script('custom',get_template_directory_uri().'/assets/js/custom.js',array(),false,true);
  }
add_action('wp_enqueue_scripts','camp_school_enqueue_scripts');
add_action('wp_enqueue_scripts','camp_school_scripts_footer');

function camp_school_theme_support(){
	add_theme_support('custom-logo');
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
  add_theme_support( 'automatic-feed-links');
  add_theme_support( 'custom-header');
  add_theme_support( 'custom-background');
  add_image_size('small',100,100,array('center','center')); 

	register_nav_menus(array(
	'Primary' => __('Primary','camp-school')
	));
}
add_action('after_setup_theme','camp_school_theme_support');
add_filter( 'image_size_names_choose', 'camp_school_small_custom_sizes' );
 
function camp_school_small_custom_sizes( $sizes ) {
    return array_merge( $sizes, array(
        'small' => __( 'Small','camp-school' ),
    ) );
}
/**
 * Add a sidebar.
 */
function camp_school_main_sidebar() {
    register_sidebar( array(
        'name'          => __( 'Main Sidebar', 'camp-school' ),
        'id'            => 'main-sidebar',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'camp-school' ),
        'before_widget' => '<div>',
        'after_widget'  => '</div>',
    ) );
}
add_action( 'widgets_init', 'camp_school_main_sidebar' );

// Contact Form Match to Template.

add_action( 'wpcf7_init', 'custom_views_post_title' );
  
function custom_views_post_title() {
    wpcf7_add_form_tag( 'custom_views_post_title', 'custom_views_post_title_shortcode_handler' );
}
  
function custom_views_post_title_shortcode_handler( $tag ) {
    global $post;
    $args = array( 'post_type' => 'post' );
    $myposts = get_posts( $args );
    $output = '<select name="lstdate" id="fleet" onchange="document.getElementById(\'fleet\').value=this.value;"><option></option>';
    foreach ( $myposts as $custom_views_post ) : setup_postdata($post);
       $title = get_the_title();
       $output .= '<option value="'. $post->ID .'">'. $title .' </option>';
       
    endforeach;
    $output .= "</select>";
    return $output; 
 
}

function mod_contact7_form_content( $template, $prop ) {
  if ( 'form' == $prop ) {
    return implode( '', array(
    
    ) );
  } else {
    return $template;
  } 
}
add_filter( 'use_block_editor_for_post', '__return_false' );
add_filter(
  'wpcf7_default_template',
  'mod_contact7_form_content',
  10,
  2
);
function mod_contact7_form_title( $template ) {
  $template->set_title( 'Contact us now' );
  return $template;
}
add_filter(
  'wpcf7_contact_form_default_pack',
  'mod_contact7_form_title'	
);

function camp_school_shapeSpace_allowed_html() {

  $allowed_tags = array(
    'a' => array(
      'class' => array(),
      'href'  => array(),
      'rel'   => array(),
      'title' => array(),
    ),
    'abbr' => array(
      'title' => array(),
    ),
    'b' => array(),
    'blockquote' => array(
      'cite'  => array(),
    ),
    'cite' => array(
      'title' => array(),
    ),
    'code' => array(),
    'del' => array(
      'datetime' => array(),
      'title' => array(),
    ),
    'dd' => array(),
    'div' => array(
      'class' => array(),
      'title' => array(),
      'style' => array(),
    ),
    'dl' => array(),
    'dt' => array(),
    'em' => array(),
    'h1' => array(),
    'h2' => array(),
    'h3' => array(),
    'h4' => array(),
    'h5' => array(),
    'h6' => array(),
    'i' => array(),
    'img' => array(
      'alt'    => array(),
      'class'  => array(),
      'height' => array(),
      'src'    => array(),
      'width'  => array(),
    ),
    'li' => array(
      'class' => array(),
    ),
    'ol' => array(
      'class' => array(),
    ),
    'p' => array(
      'i' => array(),
      'class' => array(),
      'a' => array(),
    ),
    'q' => array(
      'cite' => array(),
      'title' => array(),
    ),
    'span' => array(
      'class' => array(),
      'title' => array(),
      'style' => array(),
    ),
    'strike' => array(),
    'strong' => array(),
    'ul' => array(
      'class' => array(),
    ),
  );
  
  return $allowed_tags;
}


/** Custom Meta Box for Author url **/
require get_template_directory().'/inc/tiny-pic.php';
require get_template_directory().'/inc/customizer-config.php';
/** TGM Plugin Activation **/
require_once get_template_directory().'/inc/class-tgm-plugin-activation.php';
require_once get_template_directory().'/inc/campschool-demo-content.php';
require get_template_directory().'/inc/install-plugins.php';
