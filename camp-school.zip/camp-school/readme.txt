=== Camp School ===
Contributors: subhanali
Tags: one-column, custom-background, custom-colors, custom-logo, custom-menu, editor-style, featured-images, footer-widgets
Requires at least: 4.0
Requires PHP: 7.0
Tested up to: 4.3-alpha
Stable tag: 1.0.3
License: GPL-2.0-or-later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==
This is most preferable for single page webite. You can control or edit full main page from customizer. One click demo import is availble to bring the whole site on single click.

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

== Changelog ==

= 1.0 =
* Added new option

= 0.5 =
* Security bug addressed
* Changed thumbnail size

== Upgrade Notice ==

= 1.0 =
* It will be recommended to upgrade the theme as the update is available, because most of the flaus are being set and the features were updated as per the requiremnt.

= 0.5 =

* This version fixes a customizing related bug.  Upgrade immediately.

== Resources ==
* magnify.jpg © 2014 Subhan DoAlie, CC0
* supermenu.js © 2013-2015 Subhan Today, MIT 