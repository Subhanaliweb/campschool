    
    <section class="section contact" data-section="section6">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="section-heading">
            <h3><?php echo esc_html(get_theme_mod('contact_title','Let’s Keep In Touch')); ?></h3>
          </div>
        </div>
        <div class="col-md-6">
        <?php
              echo do_shortcode(

                '[contact-form-7 id="398" title="Keep In Touch"]'
                );
            ?>
        </div>
        <div class="col-md-6">
          <div id="map">
            <iframe src="<?php echo esc_url(get_theme_mod('map_link','https://maps.google.com/maps?q=Av.+L%C3%BAcio+Costa,+Rio+de+Janeiro+-+RJ,+Brazil&t=&z=13&ie=UTF8&iwloc=&output=embed')); ?>" width="100%" height="422px" frameborder="0" style="border:0" allowfullscreen></iframe>
          </div>
        </div>
      </div>
    </div>
  </section>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <?php $allowed_html = camp_school_shapeSpace_allowed_html(); ?>
          <?php echo wp_kses(get_theme_mod('footer_settings','<p><i class="fa fa-copyright"></i> Copyright 2021 by Camp School  
          
           | Design: <a href="https://wordpress.com" rel="sponsored" target="_parent">Camp School</a></p>'), $allowed_html); ?>
          
        </div>
      </div>
    </div>
  </footer>
  <?php wp_footer() ?>
  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->

    <script>
        //according to loftblog tut
        $('.nav li:first').addClass('active');

        var showSection = function showSection(section, isAnimate) {
          var
          direction = section.replace(/#/, ''),
          reqSection = $('.section').filter('[data-section="' + direction + '"]'),
          reqSectionPos = reqSection.offset().top - 0;

          if (isAnimate) {
            $('body, html').animate({
              scrollTop: reqSectionPos },
            800);
          } else {
            $('body, html').scrollTop(reqSectionPos);
          }

        };

        var checkSection = function checkSection() {
          $('.section').each(function () {
            var
            $this = $(this),
            topEdge = $this.offset().top - 80,
            bottomEdge = topEdge + $this.height(),
            wScroll = $(window).scrollTop();
            if (topEdge < wScroll && bottomEdge > wScroll) {
              var
              currentId = $this.data('section'),
              reqLink = $('a').filter('[href*=\\#' + currentId + ']');
              reqLink.closest('li').addClass('active').
              siblings().removeClass('active');
            }
          });
        };

        $('.main-menu, .scroll-to-section').on('click', 'a', function (e) {
          if($(e.target).hasClass('external')) {
            return;
          }
          e.preventDefault();
          $('#menu').removeClass('active');
          showSection($(this).attr('href'), true);
        });

        $(window).scroll(function () {
          checkSection();
        });
    </script>

</body>
</html>